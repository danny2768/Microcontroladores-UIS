# ESP32 GPS Plotter with Google Maps
## Full tutorial: https://www.teachmemicro.com/esp32-gps-google-maps/

Plot ESP32 + GPS device location in Google Maps. 
* Requires [Google Maps API key](https://developers.google.com/maps/documentation/javascript/overview)
* ESP32 must be online (use WiFi)

