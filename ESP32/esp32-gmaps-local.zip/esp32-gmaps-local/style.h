const String style PROGMEM  = "#map {"
        "height: 100%;"
      "}"
      
      "html,"
      "body {"
        "height: 100%;"
        "margin: 0;"
        "padding: 0;"
      "}";
